<?php
	$servername = 'localhost';
	$username ='root';
	$password = 'rats';
	$dbname = 'rats';
	$conn = mysqli_connect($servername, $username, $password, $dbname);
			
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . mysqli_connect_error());
	}
	
	$numCities = $_POST["numCities"];
	$city1 = $_POST["city1"];
	$city2 = $_POST["city2"];
	$city3 = $_POST["city3"];
	$city4 = $_POST["city4"];
	if ($city1 == '') { $city1 = "Brooklyn"; }
        if ($city2 == '') { $city2 = "Brooklyn"; }
        if ($city3 == '') { $city3 = "Brooklyn"; }
        if ($city4 == '') { $city4 = "Brooklyn"; }

	$c1_sql = "SELECT location_type, COUNT(rkey) AS count FROM Rats WHERE city LIKE '%$city1%' GROUP BY location_type";
	$c2_sql = "SELECT location_type, COUNT(rkey) AS count FROM Rats WHERE city LIKE '%$city2%' GROUP BY location_type";
	$c3_sql = "SELECT location_type, COUNT(rkey) AS count FROM Rats WHERE city LIKE '%$city3%' GROUP BY location_type";
	$c4_sql = "SELECT location_type, COUNT(rkey) AS count FROM Rats WHERE city LIKE '%$city4%' GROUP BY location_type";

	$sql = "";
	$c21 = "SELECT c1.location_type, c1.count AS count1, c2.count as count2 FROM ($c1_sql) AS c1 INNER JOIN ($c2_sql) AS c2 ON c1.location_type = c2.location_type GROUP BY c1.location_type";
	$c321 = "SELECT c21.location_type, c21.count1 AS count1, c21.count2 AS count2, c3.count AS count3 FROM ($c21) AS c21 INNER JOIN ($c3_sql) AS c3 ON c21.location_type = c3.location_type GROUP BY c21.location_type";
	$c4321 = "SELECT c321.location_type, c321.count1 AS count1, c321.count2 AS count2, c321.count3 AS count3, c4.count AS count4 FROM ($c321) AS c321 INNER JOIN ($c4_sql) AS c4 ON c321.location_type = c4.location_type GROUP BY c321.location_type";

	if ($numCities == '2'){
		$sql = $c21;
	}
	elseif($numCities == '3'){
		$sql = $c321;
	}
	elseif($numCities == '4'){
		$sql = $c4321;
	}

	$result = mysqli_query($conn, $sql);
?>


<html>
	<head>
	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	<script type = "text/javascript">
		google.charts.load('current', {'packages':['bar']});
       		google.charts.setOnLoadCallback(drawChart);
    		function drawChart() {
         
        		var data = google.visualization.arrayToDataTable([
				['Location Type','<?php echo $city1?>', <?php echo "'".$city2."'";
				if ($numCities == '3' || $numCities == '4'){
					echo ", '".$city3."'";
				}
				if($numCities == '4'){
					echo ", '".$city4."'";
				}
			?>],
				<?php
        			if (mysqli_num_rows($result)> 0) {
        		        	while($row = $result->fetch_assoc()){
 						echo '["'.$row['location_type'].'", '.$row['count1'].', '.$row['count2'];
						if ($numCities == '3' || $numCities == '4'){
							echo ', '.$row['count3'];
						}
						if($numCities == '4'){
							echo ', '.$row['count4'];
						}
						echo '],';

         				}
	     			}
				?>
			
			]);

			var options = {
	          		chart: {
        	    			title: '<?php
						$title = "Comparing Rat Sightings by Location Type in Diffent Cities";
						echo $title;
					 ?>',
          				}
        		};

            		var chart = new google.charts.Bar(document.getElementById('columnchart_material'));
                	chart.draw(data, google.charts.Bar.convertOptions(options));

                	
  		}
	</script>
	</head>
	<body>
		<div id="columnchart_material" style="width: 1000px; height: 500px;"></div>
		<a href = "make_chart.php"><button>Make a new Chart</button></a>
		<a href = "index.php"><button>Go to the index</button></a>
		
	</body>
</html>

