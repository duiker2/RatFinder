<?php

	$servername = 'localhost';
	$username ='root';
	$password = 'rats';
	$dbname = 'rats';

?>
<html>
	<body>
		<h1>Rat Finder</h1>
		<ul>
			<li><a href = "index.php ">Home</a></li>
			<li><a href = "select.php ">Search</a></li>
			<li><a href = "update.php ">Update</a></li>
			<li><a href = "map.php ">Map</a></li>
			<li><a href = "heatmap.php ">Heatmap</a></li>
			<li><a href = "make_chart.php">Make Graphs</a> </li>
		</ul>

		<h2>Insert a Rat Sighting:</h2>
		<form action="" method="post">
			City: <input id="city" type="text" name="city"><br>
			Address: <input id="address" type="text" name="address" ><br>
			Zip: <input id="zip" type="text" name="zip" ><br>
			Location Type: <input id="location_type" type="text" name="location_type" ><br>
			<button onclick="search()"> Submit </button>
		</form>
		<?php
			$conn = mysqli_connect($servername, $username, $password, $dbname);
			
			// Check connection
			if ($conn->connect_error) {
				die("Connection failed: " . mysqli_connect_error());
			}

			$city = $_POST['city'];
			if(empty($city)){
				$city = 'NULL';
			}
			else{
				$city = '\''.$city.'\'';
			}
			$address = $_POST['address'];
			if(empty($address)){
				$address = 'NULL';
			}
			else{
				$address = '\''.$address.'\'';
			}
			$zip = $_POST['zip'];
			if(empty($zip)){
				$zip = 'NULL';
			}
			else{
				$zip = '\''.$zip.'\'';
			}
			$location_type = $_POST['location_type'];
			if(empty($location_type)){
				$location_type = 'NULL';
			}
			else{
				$location_type = '\''.$location_type.'\'';
			}

			$max_key_sql = "SELECT MAX(rkey) as max FROM Rat_Sightings";			
			$max_key_rows = mysqli_query($conn, $max_key_sql);
			$max_key = -1;
			while($row = $max_key_rows->fetch_assoc()){
				$max_key = $row["max"];
				$new_key = $max_key+1;
			}

			$insert_sql = "";
			$start_trans ="START TRANSACTION;";
			$insert_sql = "INSERT INTO Rat_Sightings 
						(rkey, cr_date, closed_date, agency, agency_name, complaint_type, descriptor, location_type, zip, address, street_name, cross_street_1, cross_street_2, intersection_street_1, intersection_street_2, address_type, city, landmark, facility_type, status, due_date, resolution_action_updated_date, community_board, borough, x_coordinate, y_coordinate, park_name, park_borough, school_name, school_number, school_region, school_code, school_phone, school_address, school_city, school_state, school_zip, school_not_found, school_or_citywide_complaint, vehicle_type, taxi_company_borough, taxi_pick_up_location, bridge_highway_name, bridge_highway_direction, road_ramp, bridge_highway_segment, garage_lot_name, ferry_direction, ferry_terminal_name, latitude, longitude, location) 
						VALUES ($new_key, NULL, NULL, NULL, NULL, NULL, NULL, $location_type, $zip, $address, NULL, NULL, NULL, NULL, NULL, NULL, $city, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);";
			$commit_trans = "COMMIT;";
			
			if ($conn->query($start_trans) === TRUE && $conn->query($insert_sql) === TRUE && $conn->query($commit_trans) === TRUE) {
				echo "New record created successfully";
			} else {
				echo "City, Address, Zip, and Location Type cannot be null. ";
			}
		?>

		<h2> Delete an Entry </h2>
		<form action="" method="post">
			Key: <input id="delete_key" type="text" name="delete_key"><br>
			<button> Submit </button>
		</form>
		<form id="confirm_delete_form" action="" method="post">
			<input id="confirm_delete" type="hidden" name="confirm_delete" value="" />
			<input id="confirm_delete_key" type="hidden" name="confirm_delete_key" value="" />
		</form>
		<?php
			$conn = mysqli_connect($servername, $username, $password, $dbname);

			// Check connection
			if ($conn->connect_error) {
				die("Connection failed: " . mysqli_connect_error());
			}

			$delete_key = $_POST['delete_key'];
			$confirm_delete = $_POST['confirm_delete'];
			
			if(!empty($delete_key))
			{
				echo "<script> 
					if(window.confirm('Really delete this record?') == true){
						document.getElementById('confirm_delete').value = 'true';
					}
					else{
						document.getElementById('confirm_delete').value = 'false';
					} 
					document.getElementById('confirm_delete_key').value = '".$delete_key."';
					document.getElementById('confirm_delete_form').submit();
				</script>";				
			}

			if(!empty($confirm_delete)){
				$confirm_delete_key = $_POST['confirm_delete_key'];
				$commit_trans = "COMMIT;";
				$rollback_trans = "ROLLBACK;";
				$start_trans ="START TRANSACTION;";
				$delete_sql = "DELETE FROM Rat_Sightings WHERE rkey = $confirm_delete_key";
				$select_sql = "SELECT rkey FROM Rat_Sightings WHERE rkey = $confirm_delete_key";
				$result = $conn->query($select_sql);
				if ($result->num_rows > 0 )
				{
					if($conn->query($start_trans) === TRUE && $conn->query($delete_sql) === TRUE){
						if($confirm_delete == 'true' && $conn->query($commit_trans) === TRUE){
							echo "Record deleted successfully";
						}
						else if($conn->query($rollback_trans) === TRUE){
							echo "Transaction rolled back";
						}
					}
				}
				else{
					echo "Record not found";
				}
			}
		?>
		<p>Created By: Wyatt Duiker, Michael Rush, Alison Wen, and Jiwon Kwak</p>
	</body>
<html>

