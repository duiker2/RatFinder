<?php
	$servername = 'localhost';
	$username ='root';
	$password = 'rats';
	$dbname = 'rats';
	$conn = mysqli_connect($servername, $username, $password, $dbname);
			
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . mysqli_connect_error());
	}
	$region = $_POST["region"];
	$city = $_POST["city"];
	$compare = $_POST["compare"];
	
	$sql = "";

	if ($region == "all"){
		$sql = "SELECT $compare, COUNT(rkey) AS count  FROM Rats WHERE $compare != '' GROUP BY $compare";
	}
	else{
		
		$sql = "SELECT $compare, COUNT(rkey) AS count FROM Rats WHERE city LIKE '%$city%'AND $compare != '' GROUP BY $compare";
	}

	$result = mysqli_query($conn, $sql);
				

?>


<html>
	<head>
	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	<script type = "text/javascript">
		google.charts.load('current', {'packages':['bar']});
       		google.charts.setOnLoadCallback(drawChart);
    		function drawChart() {
         
        		var data = google.visualization.arrayToDataTable([
				[<?php echo"'".$compare."'"; ?>, 'Rat Sightings'],
				<?php
        			if (mysqli_num_rows($result)> 0) {
        		        	while($row = $result->fetch_assoc()){
 						echo '["'.$row[$compare].'", '.$row['count'].'],';
         				}
	     			}
				?>
			
			]);

			var options = {
	          		chart: {
        	    			title: '<?php
						$title = "Comparing Rat Sightings by ".$compare. " in ";
						if ($region == 'all'){
							$title = $title."New York (the state)";
						}
						else{
							$title = $title.$city;
						}
						echo $title;
					 ?>',
          				}
        		};

            		var chart = new google.charts.Bar(document.getElementById('columnchart_material'));
                	chart.draw(data, google.charts.Bar.convertOptions(options));

                	
  		}
	</script>
	</head>
	<body>
		<div id="columnchart_material" style="width: 1000px; height: 500px;"></div>
		<a href = "make_chart.php"><button>Make a new Chart</button></a>
		<a href = "index.php"><button>Go to the index</button></a>
		
	</body>
</html>
