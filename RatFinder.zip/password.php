<php?
return array(
	$servername = "localhost",
	$username = "root",
	$password = "rats",
	$dbname = "rats",
);
?>
