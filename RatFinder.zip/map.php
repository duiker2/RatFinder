<?php

	$servername = 'localhost';
	$username ='root';
	$password = 'rats';
	$dbname = 'rats';
	$apikey = 'AIzaSyBljq5hMizN3RaAg_ODY3VRnag6ayVHxJE'

?>
<html>
	<body>
		<h1>Rat Finder</h1>
		<ul>
			<li><a href = "index.php ">Home</a></li>
			<li><a href = "select.php ">Search</a></li>
			<li><a href = "update.php ">Update</a></li>
			<li><a href = "map.php ">Map</a></li>
			<li><a href = "heatmap.php ">Heatmap</a></li>
			<li><a href = "make_chart.php">Make Graphs</a> </li>
		</ul>
		<h2>Options</h2>
		<form method="POST" action="">
			Number of Points: <select id = 'points'  name = "points"> 
				<option value = '10'>10</option>
				<option value = '50'>50</option>
				<option value = '200'>200</option>
				<option value = '10000'>10000</option>
			</select><br>
			Zip: <input id = "zipcode" type="text" name="zipcode"><br>
			<button onclick="search()"> Submit </button>
		<div id="googleMap" style="width:100%;height:620px;"></div>

		<script>
			var map;
			
			function myMap() {
				var mapProp= {
					center:new google.maps.LatLng(40.710334,-73.920597),
					zoom:11,
				};
				map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
				google.maps.event.addListener(map,'click',function(){infowindow.close();});
			}

			function addMarker(rkey, latitude, longitude, zip, address, city){
				
					
				var infowindow = new google.maps.InfoWindow({

					content: "Zip: "+zip+"<br>Address: " + address+ "<br>City: "+ city
					
				});

				var marker = new google.maps.Marker({
					position: {lat: latitude, lng: longitude},
					map: map,
					title:'rkey: '+rkey+'\nAd' 
				});
				marker.addListener('click',function(){
					
					infowindow.open(map, marker); 
								
				});
			}
		</script>

		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBljq5hMizN3RaAg_ODY3VRnag6ayVHxJE&callback=myMap"></script>

		<?php
			$conn = mysqli_connect($servername, $username, $password, $dbname);
			
			// Check connection
			if ($conn->connect_error) {
				die("Connection failed: " . mysqli_connect_error());
			}
			$points = $_POST['points'];
			if (empty($points)){
				$points = '200';
			}
			$zip = $_POST['zipcode'];
			if (empty($zip)){
				$sql = "SELECT rkey, latitude, longitude,zip, address, city  FROM `Rat_Sightings` WHERE `latitude` IS NOT NULL AND `longitude` IS NOT NULL LIMIT $points";
			}	 
			else
				$sql = "SELECT rkey, latitude, longitude,zip, address, city  FROM `Rat_Sightings` WHERE zip = $zip AND `latitude` IS NOT NULL AND `longitude` IS NOT NULL LIMIT $points";
			
			$result = mysqli_query($conn, $sql);
			
			if (mysqli_num_rows($result)> 0) {
				echo "<script>";
				while($row = $result->fetch_assoc()){
					echo 'addMarker('.$row['rkey'].','.$row['latitude'].','.$row['longitude'].',"'.$row['zip'].'","'.$row['address'].'","'.$row['city'].'");';
					echo "\n";
				}
				echo " </script>";
			}
			else{
				echo "No Data Available";
			}
			
			$sql = "SELECT rkey, address, zip  FROM `Rat_Sightings` WHERE `latitude` IS NULL OR `longitude` IS NULL";
			$result = mysqli_query($conn, $sql);
			if (mysqli_num_rows($result)> 0) {
				while($row = $result->fetch_assoc()){
					$address = str_replace(" ", "+", $row["address"])."+".str_replace(" ", "+", $row["zip"]);
					$url = "https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyBljq5hMizN3RaAg_ODY3VRnag6ayVHxJE&address=".$address;
					
					$curl = curl_init($url);
					curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
					$response = curl_exec($curl);
					if ($response === false) {
						$info = curl_getinfo($curl);
						curl_close($curl);
						die('error occured during curl exec. Additioanl info: ' . var_export($info));
					}
					curl_close($curl);

					echo "<script>";
					$arr = json_decode($response, true);		
					if($arr['status'] == "OK"){
						$lat =  $arr['results'][0]['geometry']['location']['lat'];
						$lng =  $arr['results'][0]['geometry']['location']['lng'];
						echo 'addMarker('.$row['rkey'].','.$lat.','.$lng.',"'.$row['zip'].'","'.$row['address'].'","'.$row['city'].'");';
						echo "\n";
					}
					echo " </script>";
				}
			}
		?>
	</body>
</html>
