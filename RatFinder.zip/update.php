<?php

	$servername = 'localhost';
	$username ='root';
	$password = 'rats';
	$dbname = 'rats';

?>
<html>
	<body>
		<h1>Rat Finder</h1>
		<ul>
			<li><a href = "index.php ">Home</a></li>
			<li><a href = "select.php ">Search</a></li>
			<li><a href = "update.php ">Update</a></li>
			<li><a href = "map.php ">Map</a></li>
			<li><a href = "heatmap.php ">Heatmap</a></li>
			<li><a href = "make_chart.php">Make Graphs</a> </li>
		</ul>


		<h2> Update an Entry </h2>
		<form action="" method="post">
			Key: <input id="update_key" type="text" name="update_key"><br>
			City: <input id="update_city" type="text" name="update_city"><br>
			Address: <input id="update_address" type="text" name="update_address" ><br>
			Zip: <input id="update_zip" type="text" name="update_zip" ><br>
			Location Type: <input id="update_location_type" type="text" name="update_location_type" ><br>
			<button> Submit </button>
		</form>
		<?php
			$conn = mysqli_connect($servername, $username, $password, $dbname);

			// Check connection
			if ($conn->connect_error) {
				die("Connection failed: " . mysqli_connect_error());
			}
			/*
			$sql = "CREATE TRIGGER `display_updated_address` AFTER UPDATE ON `Rat_Sightings`
					FOR EACH ROW 
					BEGIN
						dbms_output.put_line('Updated key: ' || update_key);
					END;
			";*/ 
				
			$update_key = $_POST['update_key'];
			$update_city = $_POST['update_city'];
			$update_address = $_POST['update_address'];
			$update_zip = $_POST['update_zip'];
			$update_location_type = $_POST['update_location_type'];
			
						
			
			if(!empty($update_key))
			{	
								

				$update_sql = "UPDATE Rat_Sightings SET ";
				if(!empty($update_city) || !empty($update_address) || !empty($update_zip) || !empty($update_location_type))
				{
					
					
					
					if (!empty($update_city))
					{	
						$update_sql .= "city = '$update_city',";
					}
					if (!empty($update_address))
					{
						$update_sql .= "address = '$update_address',";
					}
					if (!empty($update_zip))
					{
						$update_sql .= "zip = '$update_zip',";
					}
					if (!empty($update_location_type))
					{
						$update_sql .= "location_type = '$update_location_type',";
					}
					$update_sql = substr($update_sql, 0, -1);		
					$update_sql .= " WHERE rkey = $update_key";
					//echo $update_sql;
				

					if ($conn->query($update_sql) === TRUE) {
						echo "Record updated successfully";
			//			$conn->query($sql);
						
					} else {
						echo "Error updating record: " . $conn->error;
					}
				}
				else 
				{
					echo "Nothing to update";
				
				}
			}
		?>

		<p>Created By: Wyatt Duiker, Michael Rush, Alison Wen, and Jiwon Kwak</p>
	</body>
<html>
