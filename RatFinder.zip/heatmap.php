<?php

	$servername = 'localhost';
	$username ='root';
	$password = 'rats';
	$dbname = 'rats';
	$apikey = 'AIzaSyBljq5hMizN3RaAg_ODY3VRnag6ayVHxJE'

?>
<html>
	<body>
		<h1>Rat Finder</h1>
		<ul>
			<li><a href = "index.php ">Home</a></li>
			<li><a href = "select.php ">Search</a></li>
			<li><a href = "update.php ">Update</a></li>
			<li><a href = "map.php ">Map</a></li>
			<li><a href = "heatmap.php ">Heatmap</a></li>
			<li><a href = "make_chart.php">Make Graphs</a> </li>
		</ul>
		<button onclick="toggleHeatmap()">Toggle Heatmap</button>
		<div id="googleMap" style="width:100%;height:720px;"></div>
		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBljq5hMizN3RaAg_ODY3VRnag6ayVHxJE&libraries=visualization"></script>

		<script>
			var map, heatmap;
			var mapProp= {
				center:new google.maps.LatLng(40.710334,-73.920597),
				zoom:11,
          		mapTypeId: 'satellite'
			};
			map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
			heatmap = new google.maps.visualization.HeatmapLayer({
				data: getPoints(),
				map: map,
				maxIntensity: 100
			});
				
			function toggleHeatmap() {
				heatmap.setMap(heatmap.getMap() ? null : map);
			}
			heatmap.setMap(map);

			function getPoints() {
					return [
						<?php
							$conn = mysqli_connect($servername, $username, $password, $dbname);
							// Check connection
							if ($conn->connect_error) {
								die("Connection failed: " . mysqli_connect_error());
							}
				
							$sql = "SELECT rkey, latitude, longitude  FROM `Rat_Sightings` WHERE `latitude` IS NOT NULL AND `longitude` IS NOT NULL";
							
							$result = mysqli_query($conn, $sql);
							if (mysqli_num_rows($result)> 0) {
									while($row = $result->fetch_assoc()){
										echo "new google.maps.LatLng(".$row["latitude"].",".$row["longitude"]."),";
										echo "\n";
									}
							}
							$sql = "SELECT rkey, address, zip  FROM `Rat_Sightings` WHERE `latitude` IS NULL OR `longitude` IS NULL";
							$result = mysqli_query($conn, $sql);
							if (mysqli_num_rows($result)> 0) {
								while($row = $result->fetch_assoc()){
									$address = str_replace(" ", "+", $row["address"])."+".str_replace(" ", "+", $row["zip"]);
									$url = "https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyBljq5hMizN3RaAg_ODY3VRnag6ayVHxJE&address=".$address;
									
									$curl = curl_init($url);
									curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
									$response = curl_exec($curl);
									if ($response === false) {
										$info = curl_getinfo($curl);
										curl_close($curl);
										die('error occured during curl exec. Additioanl info: ' . var_export($info));
									}
									curl_close($curl);

									$arr = json_decode($response, true);		
									if($arr['status'] == "OK"){
										$lat =  $arr['results'][0]['geometry']['location']['lat'];
										$lng =  $arr['results'][0]['geometry']['location']['lng'];
										echo "new google.maps.LatLng(".$lat.",".$lng."),\n";
									}
								}
							}
						?>
					];
				}
		</script>
	</body>
</html>
