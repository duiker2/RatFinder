<?php

	$servername = 'localhost';
	$username ='root';
	$password = 'rats';
	$dbname = 'rats';

?>
<html>
	<head>
		<style>
			table, th, td {
				border: 1px solid black;
			}
			td {
				padding: 10px
			}
		</style>
	<title>Rat Search </title>
	</head>
	<body>
		<h1>Rat Search</h1>
		<ul>
			<li><a href = "index.php ">Home</a></li>
			<li><a href = "select.php ">Search</a></li>
			<li><a href = "update.php ">Update</a></li>
			<li><a href = "map.php ">Map</a></li>
			<li><a href = "heatmap.php ">Heatmap</a></li>
			<li><a href = "make_chart.php">Make Graphs</a> </li>
		</ul>
		<form action="" method="post">
			Key: <input id="rkey" type="nt" name="rkey"><br>
			Street Name: <input id="streetname" type="text" name="streetname"><br>
			City: <input id="city" type="text" name="city"><br>
			Zip: <input id="zipcode" type="text" name="zipcode" ><br>
			Order: <select name = 'order'>
				<option value = 'rkey'>Key</option>
				<option value = 'city'>City</option>
				<option value = 'zip'>Zip</option>
				<option value = 'address'>Address</option>
			</select>
			<select name = 'when'>
				<option value = ' DESC'>Descending</option>
				<option value = ' ASC'>Ascending</option>
			</select><br>
			Max results you want to see: <input id="limit" type="int" name="limit" ><br>
			<button onclick="search()"> Submit </button>
		</form>
		<p>Note: Please be aware that if you input a key all other information required is unneeded. Also if you enter all or ALL (no spaces) into rkey all rat sightings will be listed.</p>
		<?php
			$conn = mysqli_connect($servername, $username, $password, $dbname);
			
			// Check connection
			if ($conn->connect_error) {
				die("Connection failed: " . mysqli_connect_error());
			}

			$view_sql = "CREATE VIEW Rats AS SELECT rkey, city, address, zip, location_type FROM Rat_Sightings";

                        $conn->query($view_sql);       
			
			$rkey = $_POST['rkey'];
			$city = $_POST['city'];				
			$zip = $_POST['zipcode'];
			$street_name = $_POST['streetname'];
			$limit = $_POST['limit'];
			$order = $_POST['order'];
			$when = $_POST['when']; 
			$sql = "SELECT * FROM Rats WHERE 1=0";

			if (!empty($rkey)){
				$sql = "SELECT * FROM Rats";
				if ($rkey != "ALL" && $rkey != "all"){
					$sql = $sql." WHERE rkey = $rkey";
				}
				$sql= $sql." ORDER BY CASE WHEN $order = '' THEN 1 ELSE 0 END, $order".$when;
			}
			else{
				$street_sql = "";
				$zip_sql = "";
				$city_sql = "";
				if (!empty($city)){
					$city_sql = "SELECT * FROM Rats WHERE city like '%$city%'";
				}
				if(!empty($street_name)) {
					$street_sql = "SELECT *  FROM Rats WHERE address like '%$street_name%'";
				}
				if (!empty($zip)){
					$zip_sql = "SELECT * FROM Rats WHERE zip=$zip";
				}
	
				if(!empty($street_name) && !empty($zip)){
					$sql = "SELECT zip.rkey, zip.city, zip.address, zip.zip, zip.location_type FROM ($zip_sql) AS zip INNER JOIN ($street_sql) AS street ON zip.rkey = street.rkey  ORDER BY CASE WHEN zip.$order = '' THEN 1 ELSE 0 END, zip.$order";
				}
				elseif(!empty($street_name) && empty($zip)){
					$sql = $street_sql." ORDER BY CASE WHEN $order = '' THEN 1 ELSE 0 END, $order";
				}
				elseif(empty($street_name) && !empty($zip)){
					$sql = $zip_sql." ORDER BY CASE WHEN $order = '' THEN 1 ELSE 0 END, $order ";
				}
				
				if (!empty($street_name) && !empty($zip) && !empty($city)){
					$sql = "SELECT city.rkey, city.city, city.address, city.zip, city.location_type FROM ($sql) as streetAndZip INNER JOIN ($city_sql) AS city ON streetAndZip.rkey = city.rkey ORDER BY CASE WHEN city.$order = '' THEN 1 ELSE 0 END, city.$order";
				}
				elseif(!empty($street_name) && empty($zip) && !empty($city)){
					$sql = "SELECT city.rkey, city.city, city.address, city.zip, city.location_type FROM ($street_sql) AS street INNER JOIN ($city_sql) AS city ON street.rkey = city.rkey ORDER BY CASE WHEN city.$order = '' THEN 1 ELSE 0 END, city.$order";
				}
				elseif(empty($street_name) && !empty($zip) && !empty($city)){
					$sql = "SELECT city.rkey, city.city, city.address, city.zip, city.location_type FROM ($zip_sql) as zip INNER JOIN ($city_sql) AS city ON zip.rkey = city.rkey ORDER BY CASE WHEN city.$order = '' THEN 1 ELSE 0 END, city.$order";
				}
				elseif(empty($street_name) && empty($zip) && !empty($city)){
					$sql = $city_sql. " ORDER BY CASE WHEN $order = '' THEN 1 ELSE 0 END, $order";
				}
				$sql = $sql.$when;
				if (!empty($limit)){
					$sql = $sql." LIMIT $limit";
				}
			}
		
			$result = mysqli_query($conn, $sql);
				
			if (mysqli_num_rows($result)> 0) {
				echo "<table>";
					echo "<tr>";
						echo "<th>Key </th>";
						echo "<th>City </th>";
						echo "<th>Address </th>";
						echo "<th>Zip </th>";
						echo "<th>Location Type </th>";
					echo "</tr>";
					while($row = $result->fetch_assoc()){
						echo "<tr>";
							echo "<td>".$row["rkey"]."</td>";
							echo "<td>".$row["city"]."</td>";
							echo "<td>".$row["address"]."</td>";
							echo "<td>".$row["zip"]."</td>";
							echo "<td>".$row["location_type"]."</td>";
						echo "</tr>";
					}
				echo "</table>";
			}
			else{
				echo "No Data Available";
			}	
	?>
	</body>
<html>

