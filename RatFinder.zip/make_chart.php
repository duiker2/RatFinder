<html>
	<head>
		<title>What do you want to graph?</title>
	</head>
	<body>
		<h1>Rat Sighting Graphs</h1>
		<ul>
			<li><a href = "index.php ">Home</a></li>
			<li><a href = "select.php ">Search</a></li>
			<li><a href = "update.php ">Update</a></li>
			<li><a href = "map.php ">Map</a></li>
			<li><a href = "heatmap.php ">Heatmap</a></li>
			<li><a href = "make_chart.php">Make Graphs</a> </li>
		</ul>
		<h2>Graphing a Region</h2>
		<form method="POST" action="graph.php">
			<h3>What region do you want to graph</h3>
			<select name = 'region'>
				<option value = 'all'>All of New York</option>
				<option value = 'city'>City</option>
			</select><br>			
			<h4>If you selected City, what is the name of the city</h4>
			<input id = "city" type = "text" name = "city"> <br>
			<h3>What do you want to compare</h3>
			<select name = 'compare'>
				<option value = 'city'>City</option>
				<option value = 'address'>Address</option>
				<option value = 'zip'>Zip</option>
				<option value = 'location_type'>Location Type</option>
			</select><br> <br>
			<input type="submit" value="Submit">
		</form>
		<p>Note: Comparing Rat Sightings by Location Type takes a long time to load.</p>
		<h2>Comparing Rat Sightings at similar locations types over different cities</h2>
                <form method="POST" action="comparing_cities.php">
                        <h3>How many cities do you want to compare?</h3>
                        <select name = 'numCities'>
                                <option value = 2>2</option>
				<option value = 3>3</option>
                                <option value = 4>4</option>
                        </select><br>
                        <h4>What are the names of the cities</h4>
                        <input id = 'city1' type = 'text' name = 'city1'> <br>
                        <input id = 'city2' type = 'text' name = 'city2'> <br> 
			<input id = 'city3' type = 'text' name = 'city3'> <br> 
			<input id = 'city4' type = 'text' name = 'city4'> <br> 
			<input type="submit" value="Submit">
                </form>
	</body>
</html>
